/**
 * helpPanel.js (inline style injection version)
 * Self-contained: injects its own CSS so no external help.css is needed.
 */
import { quickGuide, faqs, sections, shortcuts } from '../content/helpContent.js';

const STORAGE_KEY_TAB = 'helpPanel:lastTab';
let panelEl = null;
let backdropEl = null;
let currentTab = sessionStorage.getItem(STORAGE_KEY_TAB) || 'quick';
let openState = false;
let searchInputEl = null;

function injectStyles() {
    if (document.querySelector('style[data-help-css]')) return;
    const style = document.createElement('style');
    style.setAttribute('data-help-css', 'true');
    style.textContent = HELP_CSS;
    document.head.appendChild(style);
}

function ensurePanel() {
    if (panelEl) return;
    injectStyles();

    backdropEl = document.createElement('div');
    backdropEl.className = 'help-backdrop hidden';

    panelEl = document.createElement('div');
    panelEl.id = 'help-panel';
    panelEl.className = 'help-panel hidden';
    panelEl.innerHTML = `
    <div class="help-header">
      <div class="help-title">
        <span class="logo-dot"></span> Help & Documentation
        <span class="version-badge" id="help-version"></span>
      </div>
      <div class="help-controls">
        <input type="text" id="help-search" placeholder="Search (FAQ & Docs)..." />
        <button class="help-close" id="help-close-btn" aria-label="Close Help">&times;</button>
      </div>
    </div>
    <div class="help-tabbar">
      <button data-tab="quick">Quick Guide</button>
      <button data-tab="faq">FAQ</button>
      <button data-tab="docs">Documentation</button>
      <button data-tab="shortcuts">Shortcuts</button>
    </div>
    <div class="help-body">
      <div class="help-tab" data-tab-content="quick"></div>
      <div class="help-tab" data-tab-content="faq"></div>
      <div class="help-tab" data-tab-content="docs"></div>
      <div class="help-tab" data-tab-content="shortcuts"></div>
    </div>
  `;

    document.body.appendChild(backdropEl);
    document.body.appendChild(panelEl);

    backdropEl.addEventListener('click', hide);
    document.getElementById('help-close-btn').addEventListener('click', hide);
    panelEl.querySelectorAll('.help-tabbar button').forEach(btn => {
        btn.addEventListener('click', () => setTab(btn.getAttribute('data-tab')));
    });

    searchInputEl = document.getElementById('help-search');
    searchInputEl.addEventListener('input', applySearchFilter);

    window.addEventListener('keydown', (e) => {
        if (!openState) return;
        if (e.key === 'Escape') hide();
        if (e.key === 'Tab') trapFocus(e);
    });

    renderAll();
    setTab(currentTab);
}

function trapFocus(e) {
    const focusable = panelEl.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (e.shiftKey) {
        if (document.activeElement === first) { e.preventDefault(); last.focus(); }
    } else if (document.activeElement === last) {
        e.preventDefault();
        first.focus();
    }
}

function renderAll() {
    renderQuickGuide();
    renderFAQ();
    renderDocs();
    renderShortcuts();
    const versionSpan = document.getElementById('help-version');
    if (versionSpan && window.VISOPLUS?.model?.meta?.version != null) {
        versionSpan.textContent = 'v' + window.VISOPLUS.model.meta.version;
    }
}

function renderQuickGuide() {
    const container = panelEl.querySelector('[data-tab-content="quick"]');
    container.innerHTML = '';
    quickGuide.forEach((q, idx) => {
        const sec = document.createElement('div');
        sec.className = 'hg-block';
        sec.innerHTML = `
      <button class="hg-header" data-expand="${idx}">
        <span>${q.title}</span>
        <span class="chevron">▸</span>
      </button>
      <div class="hg-content">
        <ol class="hg-steps">
          ${q.steps.map(s => `<li>${escapeHTML(s)}</li>`).join('')}
        </ol>
      </div>
    `;
        container.appendChild(sec);
    });
    container.addEventListener('click', (e) => {
        const btn = e.target.closest('.hg-header');
        if (!btn) return;
        btn.parentElement.classList.toggle('open');
    });
}

function renderFAQ() {
    const container = panelEl.querySelector('[data-tab-content="faq"]');
    container.innerHTML = `
    <div class="faq-list">
      ${faqs.map(f => `
        <div class="faq-item" data-faq>
          <div class="faq-q">${escapeHTML(f.q)}</div>
          <div class="faq-a">${escapeHTML(f.a)}</div>
        </div>`).join('')}
    </div>
  `;
    container.addEventListener('click', (e) => {
        const item = e.target.closest('.faq-item');
        if (!item) return;
        item.classList.toggle('open');
    });
}

function renderDocs() {
    const container = panelEl.querySelector('[data-tab-content="docs"]');
    container.innerHTML = `
    <div class="docs-nav">
      ${sections.map(s => `<a href="#doc-${s.id}" data-doc-link="${s.id}">${escapeHTML(s.title)}</a>`).join('')}
    </div>
    <div class="docs-content">
      ${sections.map(s => `
        <section id="doc-${s.id}" class="doc-section" data-doc-section="${s.id}">
          <h4>${escapeHTML(s.title)}</h4>
          ${s.html}
        </section>`).join('')}
    </div>
  `;
    container.querySelectorAll('.docs-nav a').forEach(a => {
        a.addEventListener('click', (e) => {
            e.preventDefault();
            const id = a.getAttribute('data-doc-link');
            const target = container.querySelector(`#doc-${id}`);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                highlightSection(target);
            }
        });
    });
}

function highlightSection(el) {
    el.classList.add('pulse');
    setTimeout(() => el.classList.remove('pulse'), 1200);
}

function renderShortcuts() {
    const container = panelEl.querySelector('[data-tab-content="shortcuts"]');
    const groups = groupBy(shortcuts, 'group');
    container.innerHTML = Object.keys(groups).map(g => `
    <div class="shortcut-group">
      <h4>${escapeHTML(g)}</h4>
      <table class="shortcut-table">
        <tbody>
          ${groups[g].map(sc => `
            <tr>
              <td class="keys"><code>${escapeHTML(sc.keys)}</code></td>
              <td class="desc">${escapeHTML(sc.desc)}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
  `).join('');
}

function applySearchFilter() {
    const q = searchInputEl.value.trim().toLowerCase();
    panelEl.querySelectorAll('[data-tab-content="faq"] .faq-item').forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = (!q || text.includes(q)) ? '' : 'none';
    });
    panelEl.querySelectorAll('[data-tab-content="docs"] .doc-section').forEach(sec => {
        const text = sec.textContent.toLowerCase();
        sec.style.display = (!q || text.includes(q)) ? '' : 'none';
    });
}

function setTab(tab) {
    currentTab = tab;
    sessionStorage.setItem(STORAGE_KEY_TAB, tab);
    panelEl.querySelectorAll('.help-tabbar button').forEach(btn =>
        btn.classList.toggle('active', btn.getAttribute('data-tab') === tab)
    );
    panelEl.querySelectorAll('.help-tab').forEach(t =>
        t.classList.toggle('active', t.getAttribute('data-tab-content') === tab)
    );
    if (searchInputEl) {
        searchInputEl.value = '';
        applySearchFilter();
    }
}

function show() {
    ensurePanel();
    openState = true;
    backdropEl.classList.remove('hidden');
    panelEl.classList.remove('hidden');
    setTimeout(() => {
        panelEl.classList.add('visible');
        backdropEl.classList.add('visible');
        searchInputEl?.focus();
    }, 10);
}
function hide() {
    if (!panelEl) return;
    openState = false;
    panelEl.classList.remove('visible');
    backdropEl.classList.remove('visible');
    setTimeout(() => {
        panelEl.classList.add('hidden');
        backdropEl.classList.add('hidden');
    }, 180);
}
function toggle() { openState ? hide() : show(); }
function isOpen() { return openState; }

/* Utilities */
function escapeHTML(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function groupBy(arr, key) {
    return arr.reduce((m, o) => { (m[o[key] || 'Other'] = m[o[key] || 'Other'] || []).push(o); return m; }, {});
}

/* Expose API */
window.VISOPLUS = window.VISOPLUS || {};
window.VISOPLUS.helpPanel = { show, hide, toggle, isOpen };

console.log('helpPanel.js loaded (inline CSS)');

const HELP_CSS = `
/* --- embedded help.css --- (identical to external version) */
.help-backdrop{position:fixed;inset:0;background:rgba(24,28,32,0.38);backdrop-filter:blur(2px);opacity:0;transition:opacity .18s ease;z-index:2400}
.help-backdrop.visible{opacity:1}
.help-backdrop.hidden{display:none}
.help-panel{position:fixed;top:54px;right:40px;width:760px;max-height:calc(100vh - 110px);background:#fff;border:1px solid #d7dde2;border-radius:16px;display:flex;flex-direction:column;box-shadow:0 24px 64px -14px rgba(0,0,0,.25);transform:translateY(10px) scale(.98);opacity:0;transition:all .2s cubic-bezier(.37,.01,.26,1);font:13px system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;z-index:2500}
.help-panel.visible{transform:translateY(0) scale(1);opacity:1}
.help-panel.hidden{display:none}
.help-header{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 18px 10px;border-bottom:1px solid #e4e8ec;background:linear-gradient(#fdfefe,#f4f7f9);border-radius:16px 16px 0 0}
.help-title{font-size:16px;font-weight:600;display:flex;align-items:center;gap:10px;letter-spacing:.5px;color:#2f3b47}
.logo-dot{width:10px;height:10px;background:var(--accent,#ff7f2a);border-radius:4px;position:relative;box-shadow:0 0 0 4px rgba(255,127,42,0.18)}
.version-badge{background:#eef3f7;color:#4e5d6b;font-size:11px;padding:2px 8px 2px;border-radius:10px;font-weight:600;letter-spacing:.6px}
.help-controls{display:flex;align-items:center;gap:10px;flex:1;justify-content:flex-end}
#help-search{flex:1;max-width:260px;height:32px;border:1px solid #ced5dc;border-radius:8px;padding:0 10px;font:inherit;outline:none;background:#fff;transition:border-color .15s,box-shadow .15s}
#help-search:focus{border-color:var(--accent,#ff7f2a);box-shadow:0 0 0 2px rgba(255,127,42,0.25)}
.help-close{background:#fff;border:1px solid #ced5dc;width:34px;height:32px;border-radius:8px;font-size:20px;line-height:1;cursor:pointer;color:#334250;transition:background .15s,border-color .15s,color .15s}
.help-close:hover{background:#ffe8da;border-color:#ffc8a3;color:#d55304}
.help-tabbar{display:flex;gap:6px;padding:8px 16px 10px;border-bottom:1px solid #e6eaee;background:#f7fafc}
.help-tabbar button{background:#fff;border:1px solid #d5dce2;border-radius:8px;padding:6px 12px;cursor:pointer;font:12px inherit;font-weight:600;letter-spacing:.5px;color:#445260;transition:background .15s,color .15s,border-color .15s}
.help-tabbar button.active,.help-tabbar button:hover{border-color:var(--accent,#ff7f2a);color:var(--accent,#ff7f2a);background:#fff}
.help-body{position:relative;overflow:hidden;flex:1;display:flex}
.help-tab{flex:1;overflow-y:auto;padding:16px 22px 28px;display:none;line-height:1.45;scroll-behavior:smooth}
.help-tab.active{display:block}
.help-tab::-webkit-scrollbar{width:10px}
.help-tab::-webkit-scrollbar-thumb{background:#d0d7dd;border-radius:7px;border:2px solid #f0f4f7}
.help-tab::-webkit-scrollbar-thumb:hover{background:#b8c1c8}
.hg-block{border:1px solid #dfe5ea;border-radius:10px;margin-bottom:12px;background:#fff;overflow:hidden}
.hg-block.open{border-color:var(--accent,#ff7f2a)}
.hg-header{width:100%;background:#f6f9fa;border:none;text-align:left;padding:10px 14px;font:13px inherit;font-weight:600;cursor:pointer;display:flex;justify-content:space-between;align-items:center;color:#41505c}
.hg-block.open .hg-header{color:var(--accent,#ff7f2a);background:#fff8f3}
.hg-header .chevron{font-size:14px;transition:transform .3s}
.hg-block.open .chevron{transform:rotate(90deg)}
.hg-content{padding:0 16px 12px;display:none;animation:fadeSlide .28s ease}
.hg-block.open .hg-content{display:block}
.hg-steps{margin:10px 0 4px;padding-left:18px;font-size:13px}
@keyframes fadeSlide{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}
.faq-list{display:flex;flex-direction:column;gap:10px}
.faq-item{border:1px solid #dde3e8;border-radius:10px;background:#fff;padding:10px 14px 8px;cursor:pointer;transition:border-color .15s}
.faq-item:hover{border-color:#c9d2d9}
.faq-item.open{border-color:var(--accent,#ff7f2a);background:#fff9f5}
.faq-q{font-weight:600;font-size:13px;letter-spacing:.2px;margin-bottom:4px;color:#374450}
.faq-a{font-size:13px;line-height:1.5;display:none;color:#3f4d58}
.faq-item.open .faq-a{display:block}
.docs-nav{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px}
.docs-nav a{text-decoration:none;background:#f3f7fa;border:1px solid #d5dce2;padding:6px 10px;border-radius:7px;font-size:11px;font-weight:600;color:#43505d;letter-spacing:.4px;transition:background .15s,color .15s,border-color .15s}
.docs-nav a:hover{background:#fff;border-color:var(--accent,#ff7f2a);color:var(--accent,#ff7f2a)}
.docs-content{display:flex;flex-direction:column;gap:24px}
.doc-section{position:relative;padding:10px 14px 6px;border:1px solid #e1e6ea;border-radius:12px;background:#fff;animation:fadeSlide .3s ease}
.doc-section h4{margin:0 0 6px;font-size:14px;font-weight:600;color:#2f3c48;letter-spacing:.4px}
.doc-section.pulse{box-shadow:0 0 0 3px rgba(255,127,42,0.25);border-color:var(--accent,#ff7f2a)}
.doc-section code{background:#fff2ea;padding:2px 5px;border-radius:4px;font-size:12px;border:1px solid #ffd8bd}
.shortcut-group{margin-bottom:22px;border:1px solid #dde3e8;border-radius:12px;background:#fff;padding:10px 14px}
.shortcut-group h4{margin:0 0 8px;font-size:13px;font-weight:600;color:#32414d}
.shortcut-table{width:100%;border-collapse:collapse;font-size:12.5px}
.shortcut-table td{padding:4px 6px 4px 2px;vertical-align:top}
.shortcut-table td.keys{white-space:nowrap;font-weight:600;color:#2f3943;width:160px}
.shortcut-table code{background:#eef3f7;padding:2px 6px;border-radius:4px;border:1px solid #dde4ea}
@media (max-width:1100px){.help-panel{right:20px;width:88vw}}
@media (max-width:760px){.help-panel{top:6vh;right:4vw;left:4vw;width:auto;height:88vh;max-height:none}.help-header{flex-wrap:wrap;gap:8px}#help-search{max-width:none;flex:1 1 100%}}
`;